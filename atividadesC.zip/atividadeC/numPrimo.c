#include <stdio.h>
//Ciencia da Computacao - UFCG
//Joicy dos Santos Silva 
//joicy.silva@ccc.ufcg.edu.br
//programa que imprime todos os números primos que estão entre 1 e 100.

int main(void)
{
	for (int i = 1; i <= 100; i++)
	{ 
		if(i%2 != 0)
		{
			printf("\nO número primo é: %d\n",i);
		}
	}
	return 0;
}
