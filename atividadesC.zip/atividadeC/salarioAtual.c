#include <stdio.h>
//Ciencia da Computacao - UFCG
//Joicy dos Santos Silva 
//joicy.silva@ccc.ufcg.edu.br
//programa Calcula salario atual

int main(void)
{
	float salario = 0;
	float aumento = 0;
	float salarioAtual = 0;
	
	printf("\nDigite o salário: R$"); 
	scanf("%f",&salario);
	
	if(salario <= 2000.00) {
		
		aumento = (salario * 13)/100;
		salarioAtual = salario + aumento;
		printf("\nO aumento foi de = R$%.2f\n",aumento);
		printf("\nO salário atual é = R$%.2f\n",salarioAtual);
		
	} else if(salario > 2000.00 && salario <= 4000.00){
				aumento = (salario * 11)/100;
				salarioAtual = salario + aumento;
				printf("\nO aumento foi de = R$%.2f\n",aumento);
				printf("\nO salário atual é = R$%.2f\n",salarioAtual);
			
			
	} else if(salario > 4000.00 && salario <= 8000.00){
				aumento = (salario * 9)/100;
				salarioAtual = salario + aumento;
				printf("\nO aumento foi de = R$%.2f\n",aumento);
				printf("\nO salário atual é = R$%.2f\n",salarioAtual);
		
	
	} else{
				aumento = (salario * 7)/100;
				salarioAtual = salario + aumento;
				printf("\nO aumento foi de = R$%.2f\n",aumento);
				printf("\nO salário atual é = R$%.2f\n",salarioAtual);
			}
	return 0;
}

