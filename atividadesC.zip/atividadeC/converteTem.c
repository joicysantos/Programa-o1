#include <stdio.h>
//Ciencia da Computacao - UFCG
//Joicy dos Santos Silva 
//joicy.silva@ccc.ufcg.edu.br
//programa que converte temperaturas Celsius para graus Fahrenheit.

int main(void)
{
	int tempCelcius = 0;
	int TempFahrenheit = 0;
	
	printf("Digite o valor em inteiro da temperatura em Celsius: ");
    scanf("%i",&tempCelcius);
	
	if (tempCelcius >= 30 && tempCelcius <= 50)
	{
		TempFahrenheit = ((tempCelcius/5)*9)+32;
		
		printf("\nO resultado da conversao de temperatura Celsius, para graus Fahrenheit foi de %d",TempFahrenheit);
		
	}else{
		printf("\nImpossível realizar a conversão. Temperatura Celsius inferior a 30°, ou superior a 50°.");
	}
	
	return 0;

}
