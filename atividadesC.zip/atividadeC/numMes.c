#include <stdio.h>
//Ciencia da Computacao - UFCG
//Joicy dos Santos Silva 
//joicy.silva@ccc.ufcg.edu.br
//programa Numero correspondete ao mes

int main(void)
{
	int numMes = 0;
	
	printf("\nDigite o número inteiro correspondente ao mês: "); 
	scanf("%i",&numMes); //%i ou %d para inteiros
	
	if(numMes == 4 || numMes == 6 || numMes == 9 || numMes == 11){
		printf("\nO mês %i tem 30 dias.\n",numMes);
		
	} else if(numMes == 2){
		printf("\nO mês %i pode ter 28 ou 29 dias, depende do ano.\n",numMes);
		
	}else{
		printf("\nO mês %i tem 31 dias.\n",numMes);
	}
	return 0;
}
