#include <stdio.h>
//Ciencia da Computacao - UFCG
//Joicy dos Santos Silva 
//joicy.silva@ccc.ufcg.edu.br
//programa Calcula o valor da comissao e do salario atual

int main(void)
{
	float vendas, comissao, salarioAtual;
	
	printf("Digite o valor da venda: ");
    scanf("%f",&vendas);
    
    comissao = (vendas * 9)/100;
    salarioAtual = comissao + 200;

	printf("\nO valor da comissão: R$%.2f\n",comissao);
	printf("\nValor do salário atual: R$%.2f\n",salarioAtual);

	return 0;
}
