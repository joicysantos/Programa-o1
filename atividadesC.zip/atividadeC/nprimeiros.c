#include <stdio.h>
//Ciencia da Computacao - UFCG
//Joicy dos Santos Silva 
//joicy.silva@ccc.ufcg.edu.br
//programa que soma os n primeiros números ímpar

int main(void)
{
	int numero = 0;
	int soma = 0;
	int cont = 0;
	
	printf("Digite o número: ");
    scanf("%i",&numero);
    
    for (int i = 1; i <= numero; i++)
    {
		soma += i + cont;
		cont = cont +1;
	}
	printf("\nA soma dos n primeiros números ímpar é: %i\n",soma);
	
	return 0;

}
