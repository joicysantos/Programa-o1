#include <stdio.h>
#include <math.h> //biblioteca matematica para importar a funcao sqrt, calcula raiz quadrada.
//Ciencia da Computacao - UFCG
//Joicy dos Santos Silva 
//joicy.silva@ccc.ufcg.edu.br
//programa equacao do segundo grau

int main(void)
{
	  int a,b,c,delta; 
	  float x1,x2; 

      printf("\nDigite o valor de A: "); 
      scanf("%i",&a);
      printf("Digite o valor de B: ");
      scanf("%i",&b);
      printf("Digite o valor de C: ");
      scanf("%i",&c);

      delta = b*b- 4 *a*c; //∆ = b^²-4ac 
      
      printf("\nO resultado do delta é: %i\n",delta);
      
      if (delta < 0)
      {
             printf("\nNao e possivel extrair a raiz deste numero\n\n");

      }else {
		  x1 = ((-b) + sqrt(delta))/(2*(a)); // (-b + √∆) / 2*a					//sqrt eh uma funcao que calcula a raiz quadrada de um numero
		  x2 = ((-b) - sqrt(delta))/(2*(a)); // (-b - √∆) / 2*a
		  
		  printf("\nO resultado da equação do segundo grau é: X1 = %.1f\n e X2 = %.1f\n",x1,x2);
	  } 
		return 0;   
}
