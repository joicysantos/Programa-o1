#include <stdio.h>

int main(void)
{
	printf("Bem vindo ao C!");
	return 0;
}
